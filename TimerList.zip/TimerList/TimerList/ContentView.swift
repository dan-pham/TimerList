//
//  ContentView.swift
//  TimerList
//
//  Created by Dan Pham on 8/2/24.
//

/*
 
 List of timers
 Counting the time on screen
 
 */

import Observation
import SwiftUI

@Observable
class RHTimer: Identifiable {
    var time: TimeInterval = 0
    var timer: Timer = Timer()
    
    var isPaused = false
    
    
    func startTime() {
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] timer in
            guard let self else { return }
            
            if !isPaused {
                self.time += 0.1
            }
        }
        
        RunLoop.current.add(timer, forMode: .common)
    }
    
}

extension ContentView {
    @Observable
    class ViewModel {
        // Ensure there are 50 timers
        var timers: [RHTimer] = []
        
        init() {
            for _ in 0..<50 {
                let timer = RHTimer()
                timers.append(timer)
            }
        }
    }
}

struct ContentView: View {
    
    @State private var viewModel = ViewModel()
    
    var body: some View {
        List(viewModel.timers) { timer in
            Text("\(timer.time.formatted(.number.precision(.fractionLength(1))))")
                .foregroundStyle(timer.isPaused ? .secondary : .primary)
                .onAppear {
                    // Start timer
                    timer.startTime()
                }
                .onDisappear {
                    // Invalidate timer
                    timer.timer.invalidate()
                }
                .onTapGesture {
                    timer.isPaused.toggle()
                }
        }
    }
    
    
}

#Preview {
    ContentView()
}

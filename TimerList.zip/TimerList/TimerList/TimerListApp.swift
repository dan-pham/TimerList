//
//  TimerListApp.swift
//  TimerList
//
//  Created by Dan Pham on 8/2/24.
//

import SwiftUI

@main
struct TimerListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
